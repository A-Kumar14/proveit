# Mastery UI Handoff (for Claude Code)

Implement this UI exactly in our Next.js app. The `reference/` folder holds the approved screens as HTML; it is the source of truth for every color, size, string and layout. When this file and a reference file disagree, the reference file wins.

## How to use this file

1. Copy this folder into the repo root as `design-handoff/` (gitignore is optional; it's fine to commit).
2. In Claude Code, run: `Read design-handoff/UI_HANDOFF.md and every file in design-handoff/reference, then build the UI in the order under Build order. Match the reference screens exactly.`
3. Don't redesign anything. If something is missing, ask before inventing it.

## Reading the reference files

They are written in a small template format. Translate them like this:

| Reference syntax | React equivalent |
| --- | --- |
| `<x-dc>…</x-dc>` | the component's JSX root |
| `{{name}}` | a prop, state value, or computed value |
| `<sc-if value="{{cond}}">` | `{cond && (…)}` |
| `<sc-for list="{{items}}" as="item">` | `{items.map(item => …)}` |
| `class Component extends DCLogic { renderVals() }` | component state + derived values (useState / useMemo) |
| `onClick="{{fn}}"` | `onClick={fn}` |
| `<a href="Map.dc.html">` | `<Link href="/course/intro-stats">` (route table below) |
| `<helmet><style>` keyframes | `globals.css` |

Every screen is a fixed 1120x720 artboard in the canvas. In the app, make the shell full-height (`h-screen`) and let the main column flex; keep all inner sizes.

## Design tokens

Light, minimal, no accent color. Font: Inter only (Caveat only inside the sketch demo).

```ts
// tailwind.config.ts  theme.extend
colors: {
  ink: { DEFAULT: "#1F1F1F", 2: "#2B2B2B", 3: "#4A4A4A", muted: "#6B6B6B", faint: "#8A8A8A" },
  surface: { DEFAULT: "#FFFFFF", sidebar: "#F7F7F7", subtle: "#FAFAFA", hover: "#F5F5F5", active: "#EFEFEF", strong: "#E8E8E8" },
  line: { DEFAULT: "#E6E6E6", button: "#DCDCDC", soft: "#E3E3E3" },
  mastered: { DEFAULT: "#2E9E5B", text: "#23824A", bg: "#EEF7F1", line: "#CFE8D7" },
  developing: { DEFAULT: "#C98A0C", text: "#9A6700", bg: "#FBF3E2", line: "#EFDDB3" },
  needswork: { DEFAULT: "#D14343", text: "#B53A3A", bg: "#FBEEEE", line: "#F0D0D0" },
},
fontFamily: { sans: ["Inter", "system-ui", "sans-serif"] },
borderRadius: { sm: "6px", md: "8px", lg: "10px" },
```

Rules:

- Page background `#FFFFFF`. Sidebar `#F7F7F7` with a 1px `#E6E6E6` right border.
- Cards: white, 1px `#E6E6E6` border, 8px radius, no shadow. Only modals and menus get a shadow (`0 12px 32px rgba(0,0,0,0.12)` / `0 8px 24px rgba(0,0,0,0.10)`).
- Primary button: white, `#1F1F1F` text, 1px `#DCDCDC` border, 6px radius, 600 weight. Secondary: transparent, 1px `#E6E6E6` border.
- Selected / active: `#EFEFEF` fill (sidebar item, segmented control) or a 2px `#1F1F1F` outline (graph node).
- Status colors are only for mastery state: green = Mastered, amber = Developing / Transfer pending, red = Needs work / Reteaching, gray dashed = Not started. Provisionally mastered = green pale fill with a **dashed** green border.
- Headings 600 weight, never 700. Body 13–15px. Small labels 11px with 0.06–0.08em letter-spacing.
- No gradients, glows, glass blur, or dot grids. The only motion: voice orb ripple/wave, the skeleton shimmer while a card streams, and the Add-file menu. Respect `prefers-reduced-motion`.
- Icons: lucide-react, stroke 1.8–2, 13–17px.

## App shell (every screen except voice mode)

- **Sidebar, 232px:** logo (28px black square, white bar-chart glyph) + "Mastery" · Dashboard, Review queue (count pill), History · COURSES list (colored dot, name, % in faint text, "New" action) · IN <COURSE> section: Tutor, Practice, Misconception log, Course files · streak card (dashboard only) · Settings pinned at the bottom.
- **Header bar, 60px:** breadcrumb on the left (`Intro Statistics / CI interpretation` + status pill), one contextual action on the right.
- **Conversation log:** scrollable column, 28px side padding, 12–14px gap between messages.
  - User message: right-aligned bubble, `#EFEFEF` fill, 14px radius with the bottom-right corner 4px.
  - Assistant message: 30px black avatar square on the left plus a card (max-width ~780px).
- **Composer:** pinned bottom. Optional row of suggestion chips (pill, 1px border). Input row: text field, Add file (paperclip), Talk it through (mic), Send (primary).

## The card pattern (used everywhere)

One `AssistantCard` component with optional sections, in this order:

1. **Header:** small uppercase label (e.g. `MASTERY REVIEW · CONFIDENCE INTERVALS`), an 18px 600 headline, and right-aligned meta (e.g. "From 14 attempts", "3 of 3 checks agree").
2. **Table** (optional): concept / skill rows with a 6px mastery bar plus % and a status pill.
3. **Two callouts side by side** (optional): Risk (red pale) and Recommendation (neutral).
4. **Next actions** (optional): numbered link rows or buttons.
5. **Footer note:** "Numbers are computed from your attempts" on the left; "Risk and advice written by AI" on the right in amber text.

Loading state: computed fields (headline, numbers, statuses) render immediately; AI text fields show a shimmering skeleton until they stream in (see `reference/Chat.dc.html`).

## Screens and routes

| Reference file | Route | What it is |
| --- | --- | --- |
| Main.dc.html | `/` | Dashboard. "Today · all courses" card: courses table, biggest risk, recommendation, next actions. "Add a course" opens a modal (name, upload dropzone, rights checkbox, demo-course card). |
| Map.dc.html | `/course/[courseId]` | User bubble "Show me my … map" plus a course map card. **Graph / Units** toggle; graph = 12 clickable nodes; right panel = selected concept (state pill, description, two skill bars, evidence, CTA). |
| Assess.dc.html | `/course/[courseId]/practice/[conceptId]` | Question card; the composer is the answer box (Add file, Talk it through, I don't know yet, Submit). Upload replies: an "own work" confirmation or a "not your work" alert. "Switch to voice" opens voice mode (same route, full screen). |
| Diagnosis.dc.html | `…/diagnosis/[attemptId]` | Answer bubble with attachment chip, then the Diagnosis card: skills table, "Where it broke" with the flawed phrase highlighted (pale red fill + wavy red underline), recommendation, actions: Fix this gap / That's not what I meant / Explain it out loud instead. |
| Repair.dc.html | `…/lesson/[attemptId]` | Lesson card (what you said vs. what's true, 10-interval chart, source tags, "Got it, give me a new question"). Clicking it appends the user bubble and a New question card (hint toggle), and the lesson collapses behind "Show lesson". |
| Updated.dc.html | `…/result/[attemptId]` | Answer bubble, then the Mastery updated card: "Needs work" (struck through) → "Provisionally mastered" (dashed), step/result table, next review date, recommendation, actions. Plain, no celebration effects. |
| Chat.dc.html | `/course/[courseId]/tutor` | Free chat. Shows the `MasteryReview` card (headline, concepts table, biggest risk, recommendation, next actions) and its streaming skeleton via "Regenerate review". |
| Settings.dc.html | `/settings` | Not a chat. Left tab list (Learning, Voice and camera, Uploads and privacy, Appearance, Account); rows of label + description + control (segmented control, switch, select). |

## Interactions to wire exactly

- **Concept graph** (`Map`): node positions, edges and colors are in the reference file's script (`C` array plus the `<svg>` paths).
  - Node: 40px circle with a state border; check / half-fill / "!" icon.
  - Selected node: 2px `#1F1F1F` outline, 4px offset.
  - Edges: green where both ends are mastered, a dashed red edge into the needs-work node, faint dashed for not-started.
- **Graph / Units toggle:** Units shows four unit cards; clicking a row selects that concept (same selection state as the graph).
- **Add file menu** (`Assess`): in production it opens the file picker. After upload, POST to `/api/upload/check`:
  - `is_student_work && relevant` → the green confirmation message plus a chip in the composer, and the image summary goes into evaluate.
  - otherwise → the red "Upload not used · <file>" alert with "Upload my work" / "Dismiss", and the file is never sent to evaluate.
  - Keep the two demo menu items behind a `DEMO_MODE` flag only.
- **Voice mode** (`Assess`, `isSpeak` branch):
  - Orb states: listening (black core, two ripple rings), tutor speaking (dark core with 5 animated bars), muted (gray core).
  - Footer: keyboard, a Sketch / Camera / Add file segmented control, mute, End and review.
  - Showing panel is 600px wide; the orb shrinks from 270px to 190px.
  - An off-topic upload makes the tutor say "Show me your own work".
- **Lesson flow** (`Repair`): state `learn | try`, `hint`, `lessonOpen`.
- **Settings:** switches are 44x26 tracks (on = `#1F1F1F`, off = `#E6E6E6`) with a white knob; segmented control = white selected pill on a light track.

## Data the UI expects

```ts
type MasteryState = "not_started" | "developing" | "needs_work" | "provisional" | "mastered";
// Card status is a 3-value view of the DB state:
const cardStatus = (s: MasteryState) =>
  s === "mastered" ? "mastered"
  : s === "provisional" || s === "developing" ? "transfer-pending"
  : s === "needs_work" ? "reteaching" : null; // not_started rows are hidden from the review card

export const MasteryReview = z.object({
  headline: z.string(),
  concepts: z.array(z.object({
    name: z.string(),
    mastery: z.number().min(0).max(100),
    status: z.enum(["mastered", "reteaching", "transfer-pending"]),
    misconception: z.string().nullable(),
  })),
  biggestRisk: z.object({ concept: z.string(), reason: z.string() }),
  recommendation: z.string(),
  nextActions: z.array(z.string()),
});
```

- `headline`, `mastery`, and `status` are computed in code from stored attempts (stable across runs).
- Only `misconception`, `biggestRisk.reason`, `recommendation`, and `nextActions` come from the model, streamed with `streamObject`, which the client reads with `useObject`.
- Use the AI SDK's Google provider (`@ai-sdk/google`) with Gemini so the app has one provider and one API key.
- The Diagnosis card takes the evaluator output: `error_type`, `misconception_id`, `evidence_quote` (exact substring, used for the highlight), `gap_sentence`, and the vote count for "N of 3 checks agree".

## Suggested components

`components/shell/{Sidebar,HeaderBar,Composer}.tsx` · `components/chat/{UserBubble,AssistantMessage,AssistantCard,CardTable,Callout,ActionList,Skeleton}.tsx` · `components/mastery/{StatusPill,MasteryBar,SegmentBar,ConceptGraph,ConceptPanel,UnitsView}.tsx` · `components/upload/{AddFileMenu,UploadReply}.tsx` · `components/voice/{VoiceSession,Orb,ShowPanel}.tsx` · `components/settings/{Switch,Segmented,SettingRow}.tsx`

## Build order

1. Tokens in Tailwind config + Inter via `next/font/google` + the shell (Sidebar, HeaderBar, Composer) using `reference/Main.dc.html`. Gate: the shell matches the reference side by side.
2. `AssistantCard` and the chat primitives, rendered on the Dashboard with seed data.
3. Course map with the working graph, Units toggle, and selection panel.
4. Practice → Diagnosis → Lesson → Result along the demo path with seed data, navigation only.
5. Swap in the API calls (evaluate, lesson, transfer grade, upload check, mastery review stream).
6. Voice mode, then Settings.
7. Pass the checklist below.

## Done checklist

- [ ] Side by side with each reference file, colors, spacing, type sizes and strings match.
- [ ] No dark backgrounds, cyan, gradients, glows or dot grids anywhere.
- [ ] Only Inter is loaded (Caveat only in the sketch).
- [ ] Demo path clicks through: Dashboard → Course map → Practice → Diagnosis → Lesson → New question → Result.
- [ ] The off-topic upload is refused and never reaches evaluate.
- [ ] The MasteryReview card shows computed numbers instantly and streams the AI text with skeletons.
- [ ] Repeated runs with the same data show identical numbers.
- [ ] Keyboard focus is visible on every button, link, and graph node; icon-only buttons have `aria-label`.
- [ ] `prefers-reduced-motion` turns off ripple, wave, and shimmer.
